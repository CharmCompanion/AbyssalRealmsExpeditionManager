# Mini Medieval Pallete Text Ref
This text collection of colors is organized as a companion to the `Mini-Medieval-Palette-Visual-Ref.png` image. All sections are organized from darkest to lightest. Anything in `()` is referencing an expansion or a context.

Cheers,
-- VEXED

## Black, Gray, and White

- #120e23
- #534664
- #6f6e72
- #aea47e
- #dacea4 (User Interface)
- #fff1a9 (Snow & Highlights)

## Blue-green

- #349c58
- #6dba79 (Ice)

## Blue

- #2a2942
- #24505f
- #2a7d75

## Purples

- #3a1b40
- #7a2849

## Pinks

- #c23753
- #e67a84

## Reds/Orange

- #b74132
- #e67146

## Browns/Yellows

- #402e2b
- #764032
- #a15c34 (Dirt)
- #c78539
- #ebb85b (Sand)

## Greens

- #56642e
- #7e9432 (Grass)
- #c9c03d
