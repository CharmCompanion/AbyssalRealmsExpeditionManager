Hey!

With the release of Mini Medieval V2.0 a lot of sheets now contain animations. I'm include these sheets without animations to maintain backwards compatibility for anyone who needs them.

Cheers,
-- VEXED
