--Thank you for buying this packs !--
I'm Jean-Michel "S13" Clarens, a french 2D gameartist freelance.

Do not hesitate to contact me for more information or to hire me for your game !
contact@secteur13.com - www.secteur13.com

Don't forget to quote me in the credits of your game !
" Jean-Michel Clarens - s13games.itch.io - secteur13.com "


 
-----S13 CITY BUILDER 8 BITS PIXELART-----
Create your own minimalist City Builder.

16 colors palette, 16x16 px grid, 2 frames animations


---ASSETS---
These assets can be used in the software of your choice !

-114 Buildings (9 animated)
-25 Building categories : administration, airport, apartment, modern appartement, education, electricity, electricity eco, factory, farm, firefighter, hospital, house, leisure, office, parc, city parc, parking, plantation, police, port, shop, sport, storage, train station, water treatment
-10 Tilesets : grass, moutain, trees & rocks, water, roads & rails
-66 Vehicules (6 animated) : cars, trucks, boats, helicopters, planes, trains in color variants
-8 Peoples (2px tall!)
-3 FX : 2 types of animated fire and destroyed state

---5 THEMES ---
These assets are in 5 variantes of colors :
spring, summer, autumn, winter and night.

To change themes, you just have to replace the assets with the other versions, the names of the files are the same.

---GODOT - READY TO START !---
This pack also contains a preconfigured Godot project (3.3.4) :

-1 exemple map with ordered layers
-Tilesets are configured for auto-tile
-Animations ready to use
-Zoom recommended at 300%
-There is no code !
 

---LICENSE---
You may use these assets in personal or commercial projects. You may modify these assets to suit your needs. You can NOT re-distribute the file, no matter how much you modify it you can use it but not share or re-sell it.