--Thank you for buying this packs !--
I'm Jean-Michel "S13" Clarens, a french 2D gameartist freelance.

Do not hesitate to contact me for more information or to hire me for your game !
contact@secteur13.com - www.secteur13.com

Don't forget to quote me in the credits of your game !
" Jean-Michel Clarens - s13games.itch.io - secteur13.com "


 
-----S13 INTERFACE 8 BITS PIXELART-----
Create your own minimalist 8 Bits Interface !

16 colors palette, for City Builder or similar games


---WORKS PERFECTLY WITH THIS PACK---
https://s13games.itch.io/s13-city-builder-8-bits

---ASSETS---
These assets can be used in the software of your choice !

-8 counselors with 12 separate backgrounds
-45 icons
-24 buttons in 4 different colors
-5 frames and tabs
-10 progress bars
-Forms and scrollbar elements
​-Hexadecimal colors document
-Zoom recommended at 300%

---FONTS---
No fonts are provided with this pack.
I recommand to use EnterCommand by Jeti.
https://www.dafont.com/fr/enter-command.font
https://fontenddev.com/

---LICENSE---
You may use these assets in personal or commercial projects. You may modify these assets to suit your needs. You can NOT re-distribute the file, no matter how much you modify it you can use it but not share or re-sell it.